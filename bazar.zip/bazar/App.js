import { Text, SafeAreaView, StyleSheet } from 'react-native';
import MenuLinks from './navegacao/MenuLinks'

export default function App(){
  return(
    <MenuLinks />
  );
}
